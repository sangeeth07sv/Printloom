# DRYNN — Custom Print Clothing

Premium custom print clothing website built with Next.js.

## Setup

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

## Deploy to Vercel

1. Push this repo to GitHub
2. Go to vercel.com
3. Import your GitHub repo
4. Click Deploy

Done. Live in 2 minutes.

## Tech Stack

- Next.js 14
- React 18
- Deployed on Vercel
- Google Fonts (Bebas Neue + DM Sans)

## Pages

- `/` — Homepage with products, custom order form, reviews

## Coming Next

- Supabase database for orders
- Razorpay payment integration
- Admin dashboard
- Order tracking
